import React from 'react'

function Meeting() {
  return (
    <div>
      <h4>Meeting</h4>
    </div>
  )
}

export default Meeting
